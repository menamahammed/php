<?php

// 1. Explain what is cookie
// Cookie is a piece of data saved in browser and sent to server and back
// on every request/response

// 2. How to set cookies
setcookie('name', 'TheCodeholic', time() + 60);

