<?php

$companyName = 'TheCodeholic';
?>

<?php include "partials/header.php"; ?>
<h1>About us</h1>
<?php include "partials/footer.php"; ?>
