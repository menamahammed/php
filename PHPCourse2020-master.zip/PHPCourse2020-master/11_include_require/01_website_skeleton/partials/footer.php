<?php
/**
 * User: TheCodeholic
 * Date: 2/10/2020
 * Time: 8:39 AM
 */
?>

<footer>
    Copyright &copy; <?php echo $companyName ?>
</footer>
</body>
</html>

