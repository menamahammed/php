<?php
/**
 * User: TheCodeholic
 * Date: 2/13/2020
 * Time: 9:31 AM
 */
// We need to have here require not include
require_once 'math.php';

echo add(4, 5).'<br>';
echo subtract(9, 4);
