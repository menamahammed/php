<?php
/**
 * User: TheCodeholic
 * Date: 2/13/2020
 * Time: 9:31 AM
 */

function add($a, $b)
{
    return $a + $b;
}

function subtract($a, $b)
{
    return $a - $b;
}
