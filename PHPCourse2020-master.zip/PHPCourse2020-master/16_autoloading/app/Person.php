<?php
/**
 * User: TheCodeholic
 * Date: 2/16/2020
 * Time: 9:35 AM
 */

namespace app;

class Person
{

}
